package ui;

import java.util.HashMap;

import javafx.scene.layout.AnchorPane;

public interface ControladorPantalla {
	public AnchorPane getAnchor();
	public String getFXML();
}
