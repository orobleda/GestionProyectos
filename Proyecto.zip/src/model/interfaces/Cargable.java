package model.interfaces;

public interface Cargable {
	public Cargable cargar (Object o);
}
